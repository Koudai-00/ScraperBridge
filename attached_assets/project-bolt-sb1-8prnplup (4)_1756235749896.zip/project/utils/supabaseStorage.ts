import { supabase } from './supabase';
import { User, Video, Folder } from '../types';
import { generateRandomUsername } from './auth';

// Generate unique username by checking database
export async function generateUniqueUsername(): Promise<string> {
  let attempts = 0;
  const maxAttempts = 10;
  
  while (attempts < maxAttempts) {
    const username = generateRandomUsername();
    
    // Check if username already exists
    const { data, error } = await supabase
      .from('users')
      .select('id')
      .eq('username', username)
      .limit(1);
    
    if (error) {
      console.error('Error checking username uniqueness:', error);
      // If there's an error checking, still return the username
      return username;
    }
    
    // If no existing user found, username is unique
    if (!data || data.length === 0) {
      return username;
    }
    
    attempts++;
  }
  
  // Fallback: add timestamp to ensure uniqueness
  return `${generateRandomUsername()}${Date.now()}`;
}

// Auth functions
export async function signUpUser(email: string, password: string, username: string, birthdate?: Date | null): Promise<{ user: User | null; error: string | null }> {
  try {
    // Generate unique username if not provided
    let finalUsername = username;
    if (!finalUsername || !finalUsername.trim()) {
      finalUsername = await generateUniqueUsername();
    }

    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    });

    if (authError) {
      return { user: null, error: authError.message };
    }

    if (!authData.user) {
      return { user: null, error: 'ユーザーの作成に失敗しました' };
    }

    // Create user profile
    const { error: profileError } = await supabase
      .from('users')
      .insert({
        id: authData.user.id,
        username: finalUsername,
        birthdate: birthdate ? birthdate.toISOString().split('T')[0] : null,
      });

    if (profileError) {
      return { user: null, error: 'プロフィールの作成に失敗しました' };
    }

    const user: User = {
      username: finalUsername,
      isLoggedIn: true,
    };

    return { user, error: null };
  } catch (error) {
    return { user: null, error: 'アカウント作成中にエラーが発生しました' };
  }
}

export async function signInUser(email: string, password: string): Promise<{ user: User | null; error: string | null }> {
  console.log('[DEBUG] signInUser: Starting authentication');
  try {
    console.log('[DEBUG] signInUser: Calling supabase.auth.signInWithPassword');
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    console.log('[DEBUG] signInUser: Auth result:', {
      hasAuthData: !!authData,
      hasUser: !!authData?.user,
      hasSession: !!authData?.session,
      hasError: !!authError,
      error: authError?.message,
      userId: authData?.user?.id
    });

    if (authError) {
      console.log('[DEBUG] signInUser: Authentication error occurred');
      return { user: null, error: authError.message };
    }

    if (!authData.user) {
      console.log('[DEBUG] signInUser: No user in auth data');
      return { user: null, error: 'ログインに失敗しました' };
    }

    // Get user profile
    console.log('[DEBUG] signInUser: Fetching user profile from users table');
    const { data: profile, error: profileError } = await supabase
      .from('users')
      .select('username')
      .eq('id', authData.user.id)
      .single();

    console.log('[DEBUG] signInUser: Profile fetch result:', {
      hasProfile: !!profile,
      profileError: profileError?.message,
      username: profile?.username
    });

    if (profileError || !profile) {
      console.log('[DEBUG] signInUser: Profile fetch failed');
      return { user: null, error: 'ユーザー情報の取得に失敗しました' };
    }

    console.log('[DEBUG] signInUser: Creating user object');
    const user: User = {
      username: profile.username,
      isLoggedIn: true,
    };

    console.log('[DEBUG] signInUser: Sign in completed successfully');
    return { user, error: null };
  } catch (error) {
    console.error('[DEBUG] signInUser: Exception occurred:', error);
    console.error('[DEBUG] signInUser: Exception stack:', error instanceof Error ? error.stack : 'No stack trace');
    return { user: null, error: 'ログイン中にエラーが発生しました' };
  }
}

export async function signOutUser(): Promise<void> {
  await supabase.auth.signOut();
}

export async function getCurrentUser(): Promise<User | null> {
  console.log('[DEBUG] getCurrentUser: Starting');
  console.log('[DEBUG] getCurrentUser: Timestamp:', new Date().toISOString());
  
  try {
    console.log('[DEBUG] getCurrentUser: Calling supabase.auth.getUser()');
    const { data: { user: authUser } } = await supabase.auth.getUser();
    console.log('[DEBUG] getCurrentUser: Auth user result:', {
      hasAuthUser: !!authUser,
      userId: authUser?.id,
      email: authUser?.email,
      emailConfirmed: authUser?.email_confirmed_at ? 'Yes' : 'No'
    });
    
    if (!authUser) {
      console.log('[DEBUG] getCurrentUser: No auth user found');
      return null;
    }

    console.log('[DEBUG] getCurrentUser: Querying users table for profile');
    const { data: profile, error } = await supabase
      .from('users')
      .select('username')
      .eq('id', authUser.id)
      .single();

    console.log('[DEBUG] getCurrentUser: Profile query result:', {
      hasProfile: !!profile,
      error: error?.message,
      errorCode: error?.code,
      username: profile?.username
    });

    if (error && error.code === 'PGRST116') {
      // Profile doesn't exist, create one
      console.log('[DEBUG] getCurrentUser: Profile not found, creating new profile');
      const randomUsername = await generateUniqueUsername();
      console.log('[DEBUG] getCurrentUser: Generated username:', randomUsername);
      
      console.log('[DEBUG] getCurrentUser: Inserting new profile into users table');
      const { data: newProfile, error: insertError } = await supabase
        .from('users')
        .insert({
          id: authUser.id,
          username: randomUsername,
        })
        .select('username')
        .single();

      console.log('[DEBUG] getCurrentUser: Profile insert result:', {
        hasNewProfile: !!newProfile,
        insertError: insertError?.message,
        newUsername: newProfile?.username
      });

      if (insertError || !newProfile) {
        console.log('[DEBUG] getCurrentUser: Failed to create profile:', insertError?.message);
        return null;
      }

      console.log('[DEBUG] getCurrentUser: Created new profile:', newProfile);
      const user = {
        username: newProfile.username,
        isLoggedIn: true,
      };
      console.log('[DEBUG] getCurrentUser: Returning new user:', user);
      return user;
    } else if (error || !profile) {
      console.log('[DEBUG] getCurrentUser: Profile error or not found:', {
        error: error?.message,
        errorCode: error?.code,
        hasProfile: !!profile
      });
      return null;
    }

    console.log('[DEBUG] getCurrentUser: Profile found, creating user object');
    const user = {
      username: profile.username,
      isLoggedIn: true,
    };
    console.log('[DEBUG] getCurrentUser: Returning user:', user);
    return user;
  } catch (error) {
    console.error('[DEBUG] getCurrentUser: Exception occurred:', error);
    console.error('[DEBUG] getCurrentUser: Exception stack:', error instanceof Error ? error.stack : 'No stack trace');
    return null;
  }
}

// Video functions
export async function getVideos(): Promise<Video[]> {
  console.log('[DEBUG] getVideos: Starting video fetch');
  try {
    console.log('[DEBUG] getVideos: Getting current user');
    const { data: { user } } = await supabase.auth.getUser();
    console.log('[DEBUG] getVideos: User check result:', {
      hasUser: !!user,
      userId: user?.id
    });
    
    if (!user) {
      console.log('[DEBUG] getVideos: No user found, returning empty array');
      return [];
    }

    console.log('[DEBUG] getVideos: Querying videos table');
    const { data, error } = await supabase
      .from('videos')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    console.log('[DEBUG] getVideos: Query result:', {
      hasData: !!data,
      dataLength: data?.length || 0,
      error: error?.message,
      errorCode: error?.code
    });

    if (error) {
      console.error('Error fetching videos:', error);
      return [];
    }

    console.log('[DEBUG] getVideos: Mapping video data');
    return data.map(video => ({
      id: video.id,
      url: video.url,
      title: video.title,
      thumbnailUrl: video.thumbnail_url,
      source: video.source as any,
      notes: video.notes || '',
      folderId: video.folder_id,
      createdAt: video.created_at,
      videoTitle: video.video_title || '',
      videoAuthorName: video.video_author_name || '',
      videoAuthorIconUrl: video.video_author_icon_url || null,
      uniqueVideoId: video.unique_video_id || null,
    }));
  } catch (error) {
    console.error('[DEBUG] getVideos: Exception occurred:', error);
    console.error('[DEBUG] getVideos: Exception stack:', error instanceof Error ? error.stack : 'No stack trace');
    return [];
  }
}

export async function addVideo(video: Omit<Video, 'id' | 'createdAt'>): Promise<Video> {
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    throw new Error('ユーザーがログインしていません');
  }

  const newVideo = {
    user_id: user.id,
    url: video.url,
    title: video.title,
    thumbnail_url: video.thumbnailUrl,
    source: video.source,
    notes: video.notes || '',
    folder_id: video.folderId,
    video_title: video.videoTitle || '',
    video_author_name: video.videoAuthorName || '',
    video_author_icon_url: video.videoAuthorIconUrl || null,
    unique_video_id: video.uniqueVideoId || null,
  };

  const { data, error } = await supabase
    .from('videos')
    .insert(newVideo)
    .select()
    .single();

  if (error) {
    throw new Error('動画の保存に失敗しました');
  }

  return {
    id: data.id,
    url: data.url,
    title: data.title,
    thumbnailUrl: data.thumbnail_url,
    source: data.source as any,
    notes: data.notes || '',
    folderId: data.folder_id,
    createdAt: data.created_at,
    videoTitle: data.video_title || '',
    videoAuthorName: data.video_author_name || '',
    videoAuthorIconUrl: data.video_author_icon_url || null,
    uniqueVideoId: data.unique_video_id || null,
  };
}

export async function updateVideo(video: Video): Promise<Video> {
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    throw new Error('ユーザーがログインしていません');
  }

  const { data, error } = await supabase
    .from('videos')
    .update({
      title: video.title,
      notes: video.notes,
      folder_id: video.folderId,
      video_title: video.videoTitle || '',
      video_author_name: video.videoAuthorName || '',
      video_author_icon_url: video.videoAuthorIconUrl || null,
    })
    .eq('id', video.id)
    .eq('user_id', user.id)
    .select()
    .single();

  if (error) {
    throw new Error('動画の更新に失敗しました');
  }

  return {
    id: data.id,
    url: data.url,
    title: data.title,
    thumbnailUrl: data.thumbnail_url,
    source: data.source as any,
    notes: data.notes || '',
    folderId: data.folder_id,
    createdAt: data.created_at,
    videoTitle: data.video_title || '',
    videoAuthorName: data.video_author_name || '',
    videoAuthorIconUrl: data.video_author_icon_url || null,
    uniqueVideoId: data.unique_video_id || null,
  };
}

export async function removeVideo(id: string): Promise<void> {
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    throw new Error('ユーザーがログインしていません');
  }

  const { error } = await supabase
    .from('videos')
    .delete()
    .eq('id', id)
    .eq('user_id', user.id);

  if (error) {
    throw new Error('動画の削除に失敗しました');
  }
}

// Folder functions
export async function getFolders(): Promise<Folder[]> {
  console.log('[DEBUG] getFolders: Starting folder fetch');
  try {
    console.log('[DEBUG] getFolders: Getting current user');
    const { data: { user } } = await supabase.auth.getUser();
    console.log('[DEBUG] getFolders: User check result:', {
      hasUser: !!user,
      userId: user?.id
    });
    
    if (!user) {
      console.log('[DEBUG] getFolders: No user found, returning empty array');
      return [];
    }

    console.log('[DEBUG] getFolders: Querying folders table');
    const { data, error } = await supabase
      .from('folders')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: true });

    console.log('[DEBUG] getFolders: Query result:', {
      hasData: !!data,
      dataLength: data?.length || 0,
      error: error?.message,
      errorCode: error?.code
    });

    if (error) {
      console.error('Error fetching folders:', error);
      return [];
    }

    console.log('[DEBUG] getFolders: Mapping folder data');
    return data.map(folder => ({
      id: folder.id,
      name: folder.name,
      createdAt: folder.created_at,
    }));
  } catch (error) {
    console.error('[DEBUG] getFolders: Exception occurred:', error);
    console.error('[DEBUG] getFolders: Exception stack:', error instanceof Error ? error.stack : 'No stack trace');
    return [];
  }
}

export async function addFolder(name: string): Promise<Folder> {
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    throw new Error('ユーザーがログインしていません');
  }

  const newFolder = {
    user_id: user.id,
    name,
  };

  const { data, error } = await supabase
    .from('folders')
    .insert(newFolder)
    .select()
    .single();

  if (error) {
    throw new Error('フォルダの作成に失敗しました');
  }

  return {
    id: data.id,
    name: data.name,
    createdAt: data.created_at,
  };
}

export async function removeFolder(id: string): Promise<void> {
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    throw new Error('ユーザーがログインしていません');
  }

  // Get the uncategorized folder
  const { data: folders } = await supabase
    .from('folders')
    .select('*')
    .eq('user_id', user.id)
    .eq('name', '未分類');

  const uncategorizedFolder = folders?.[0];
  
  if (!uncategorizedFolder) {
    throw new Error('未分類フォルダが見つかりません');
  }

  // Move videos to uncategorized folder
  await supabase
    .from('videos')
    .update({ folder_id: uncategorizedFolder.id })
    .eq('folder_id', id)
    .eq('user_id', user.id);

  // Delete the folder
  const { error } = await supabase
    .from('folders')
    .delete()
    .eq('id', id)
    .eq('user_id', user.id);

  if (error) {
    throw new Error('フォルダの削除に失敗しました');
  }
}

// Initialize default folders for new users
export async function initializeStorage(): Promise<void> {
  console.log('[DEBUG] initializeStorage: Starting storage initialization');
  const { data: { user } } = await supabase.auth.getUser();
  console.log('[DEBUG] initializeStorage: User check result:', {
    hasUser: !!user,
    userId: user?.id
  });
  
  if (!user) {
    console.log('[DEBUG] initializeStorage: No user found, exiting');
    return;
  }

  // Check if user already has folders
  console.log('[DEBUG] initializeStorage: Checking for existing folders');
  const { data: existingFolders } = await supabase
    .from('folders')
    .select('id')
    .eq('user_id', user.id)
    .limit(1);

  console.log('[DEBUG] initializeStorage: Existing folders check:', {
    hasExistingFolders: !!(existingFolders && existingFolders.length > 0),
    existingCount: existingFolders?.length || 0
  });

  if (existingFolders && existingFolders.length > 0) {
    console.log('[DEBUG] initializeStorage: User already has folders, skipping initialization');
    return; // User already has folders
  }

  // Create default folders
  console.log('[DEBUG] initializeStorage: Creating default folders');
  const defaultFolders = [
    { user_id: user.id, name: '未分類' },
    { user_id: user.id, name: '和食' },
    { user_id: user.id, name: 'デザート' },
    { user_id: user.id, name: '簡単料理' },
  ];

  console.log('[DEBUG] initializeStorage: Inserting default folders:', defaultFolders.map(f => f.name));
  const { error } = await supabase
    .from('folders')
    .insert(defaultFolders);

  console.log('[DEBUG] initializeStorage: Default folders insert result:', {
    hasError: !!error,
    error: error?.message
  });

  if (error) {
    console.error('Error creating default folders:', error);
  } else {
    console.log('[DEBUG] initializeStorage: Default folders created successfully');
  }
}

export { signUpUser, signInUser, signOutUser, getCurrentUser, getVideos, addVideo, updateVideo, removeVideo, getFolders, addFolder, removeFolder, initializeStorage }