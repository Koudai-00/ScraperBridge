export function generateRandomUsername(): string {
  const adjectives = [
    'happy', 'sunny', 'clever', 'bright', 'swift',
    'calm', 'kind', 'brave', 'wise', 'pure'
  ];
  
  const nouns = [
    'star', 'river', 'cloud', 'bird', 'tree',
    'moon', 'sun', 'wind', 'rain', 'snow'
  ];
  
  const randomAdjective = adjectives[Math.floor(Math.random() * adjectives.length)];
  const randomNoun = nouns[Math.floor(Math.random() * nouns.length)];
  const randomNumber = Math.floor(Math.random() * 1000);
  
  return `${randomAdjective}${randomNoun}${randomNumber}`;
}