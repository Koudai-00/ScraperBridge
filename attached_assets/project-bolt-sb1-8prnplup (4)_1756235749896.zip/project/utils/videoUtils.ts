import { VideoSource } from '../types';

export function isValidUrl(url: string): boolean {
  try {
    new URL(url);
    return true;
  } catch (e) {
    return false;
  }
}

export function getVideoSource(url: string): VideoSource {
  if (!isValidUrl(url)) {
    return VideoSource.Other;
  }
  
  const urlObj = new URL(url);
  const hostname = urlObj.hostname.toLowerCase();
  
  if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
    return VideoSource.YouTube;
  } else if (hostname.includes('instagram.com')) {
    return VideoSource.Instagram;
  } else if (hostname.includes('tiktok.com')) {
    return VideoSource.TikTok;
  }
  
  return VideoSource.Other;
}

export function getYoutubeVideoId(url: string): string | null {
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname.toLowerCase();
    
    if (hostname.includes('youtube.com')) {
      return urlObj.searchParams.get('v');
    } else if (hostname.includes('youtu.be')) {
      return urlObj.pathname.split('/')[1];
    }
    
    return null;
  } catch (e) {
    return null;
  }
}

export async function getVideoMetadata(url: string) {
  try {
    const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
    const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
    
    if (!supabaseUrl || !supabaseKey) {
      console.warn('Supabase environment variables not configured');
      return null;
    }
    
    const response = await fetch(`${supabaseUrl}/functions/v1/video-metadata`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${supabaseKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      
      try {
        const errorData = JSON.parse(errorText);
        throw new Error(errorData.error || 'Failed to fetch video metadata');
      } catch (parseError) {
        throw new Error(`Failed to fetch video metadata (${response.status}): ${errorText}`);
      }
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching video metadata:', error);
    return null;
  }
}

export function generateVideoTitle(url: string): string {
  const source = getVideoSource(url);
  const now = new Date().toLocaleDateString('ja-JP');
  
  switch (source) {
    case VideoSource.YouTube:
      return `YouTube (${now})`;
    case VideoSource.Instagram:
      return `Instagram (${now})`;
    case VideoSource.TikTok:
      return `TikTok (${now})`;
    default:
      return `ビデオ (${now})`;
  }
}

export function getVideoThumbnailUrl(url: string): string {
  const source = getVideoSource(url);
  
  // Return platform-specific placeholder images
  switch (source) {
    case VideoSource.YouTube:
      return 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=400';
    case VideoSource.Instagram:
      return 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=400';
    case VideoSource.TikTok:
      return 'https://images.pexels.com/photos/4393021/pexels-photo-4393021.jpeg?auto=compress&cs=tinysrgb&w=400';
    default:
      return 'https://images.pexels.com/photos/1640772/pexels-photo-1640772.jpeg?auto=compress&cs=tinysrgb&w=400';
  }
}