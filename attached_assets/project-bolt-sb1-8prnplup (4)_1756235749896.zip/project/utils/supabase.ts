import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

console.log('[DEBUG] Supabase initialization:', {
  supabaseUrl: supabaseUrl ? 'Set' : 'Missing',
  supabaseAnonKey: supabaseAnonKey ? 'Set' : 'Missing',
  platform: typeof window !== 'undefined' ? 'web' : 'native'
});

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Database types
export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          username: string;
          created_at: string;
          birthdate: string | null;
        };
        Insert: {
          id: string;
          username: string;
          created_at?: string;
          birthdate?: string | null;
        };
        Update: {
          id?: string;
          username?: string;
          created_at?: string;
          birthdate?: string | null;
        };
      };
      folders: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          name?: string;
          created_at?: string;
        };
      };
      videos: {
        Row: {
          id: string;
          user_id: string;
          url: string;
          title: string;
          thumbnail_url: string;
          source: string;
          notes: string;
          folder_id: string;
          created_at: string;
          unique_video_id: string | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          url: string;
          title: string;
          thumbnail_url: string;
          source: string;
          notes?: string;
          folder_id: string;
          created_at?: string;
          unique_video_id?: string | null;
        };
        Update: {
          id?: string;
          user_id?: string;
          url?: string;
          title?: string;
          thumbnail_url?: string;
          source?: string;
          notes?: string;
          folder_id?: string;
          created_at?: string;
          unique_video_id?: string | null;
        };
      };
    };
  };
}