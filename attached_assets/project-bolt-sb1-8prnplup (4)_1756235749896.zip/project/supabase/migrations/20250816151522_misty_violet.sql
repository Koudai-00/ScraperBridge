/*
  # Add unique_video_id column to videos table

  1. New Column
    - `unique_video_id` (text, nullable)
      - Stores a unique identifier extracted from video URLs
      - Used to prevent duplicate video saves
      - Will be populated by application logic when videos are saved

  2. Purpose
    - Enable duplicate detection for videos from the same source
    - Support deduplication across different URL formats (e.g., youtube.com vs youtu.be)
    - Improve data integrity and user experience
*/

-- Add unique_video_id column to videos table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'unique_video_id'
  ) THEN
    ALTER TABLE videos ADD COLUMN unique_video_id text;
  END IF;
END $$;