/*
  # 動画メタデータカラムの追加

  1. 変更内容
    - `videos`テーブルに以下のカラムを追加:
      - `video_platform` (text): youtube, instagram, tiktok のいずれかを保存
      - `video_title` (text): 動画のタイトルやキャプションを保存
      - `video_thumbnail_url` (text): サムネイル画像のURLを保存
      - `video_author_name` (text): 投稿者名・チャンネル名を保存
      - `video_author_icon_url` (text): 投稿者のアイコンURLを保存（null許容）

  2. 注意事項
    - 既存のデータに影響を与えないよう、すべてのカラムにデフォルト値を設定
    - 既存の`title`と`thumbnail_url`カラムは維持（後方互換性のため）
*/

DO $$
BEGIN
  -- video_platform カラムを追加
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_platform'
  ) THEN
    ALTER TABLE videos ADD COLUMN video_platform text DEFAULT '';
  END IF;

  -- video_title カラムを追加
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_title'
  ) THEN
    ALTER TABLE videos ADD COLUMN video_title text DEFAULT '';
  END IF;

  -- video_thumbnail_url カラムを追加
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_thumbnail_url'
  ) THEN
    ALTER TABLE videos ADD COLUMN video_thumbnail_url text DEFAULT '';
  END IF;

  -- video_author_name カラムを追加
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_author_name'
  ) THEN
    ALTER TABLE videos ADD COLUMN video_author_name text DEFAULT '';
  END IF;

  -- video_author_icon_url カラムを追加
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_author_icon_url'
  ) THEN
    ALTER TABLE videos ADD COLUMN video_author_icon_url text;
  END IF;
END $$;