/*
  # Add birthdate column to users table

  1. Schema Changes
    - Add `birthdate` column to `users` table
      - Type: `date` (optimal for storing birth dates)
      - Nullable: `true` (optional field)
      - Default: `null`

  2. Notes
    - Birthdate is stored as a proper date type for optimal querying and data integrity
    - Field is optional to allow registration without birthdate
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'birthdate'
  ) THEN
    ALTER TABLE users ADD COLUMN birthdate date DEFAULT null;
  END IF;
END $$;