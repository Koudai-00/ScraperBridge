/*
  # Add video metadata columns to videos table

  1. New Columns
    - `video_title` (text) - SNSから取得した動画のタイトル/キャプション
    - `video_author_name` (text) - 投稿者名/チャンネル名
    - `video_author_icon_url` (text) - 投稿者のアイコンURL

  2. Notes
    - 既存の `source` カラムを `video_platform` として使用
    - 既存の `thumbnail_url` カラムを `video_thumbnail_url` として使用
    - 新しいカラムはすべてNULL許容で、既存データとの互換性を保持
*/

-- Add video metadata columns to videos table
DO $$
BEGIN
  -- Add video_title column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_title'
  ) THEN
    ALTER TABLE videos ADD COLUMN video_title text;
  END IF;

  -- Add video_author_name column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_author_name'
  ) THEN
    ALTER TABLE videos ADD COLUMN video_author_name text;
  END IF;

  -- Add video_author_icon_url column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_author_icon_url'
  ) THEN
    ALTER TABLE videos ADD COLUMN video_author_icon_url text;
  END IF;
END $$;