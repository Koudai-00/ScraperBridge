export interface User {
  username: string;
  isLoggedIn: boolean;
}

export interface Folder {
  id: string;
  name: string;
  createdAt: string;
}

export enum VideoSource {
  YouTube = 'YouTube',
  Instagram = 'Instagram',
  TikTok = 'TikTok',
  Other = 'その他'
}

export interface Video {
  id: string;
  url: string;
  title: string;
  thumbnailUrl: string;
  source: VideoSource;
  notes: string;
  folderId: string;
  createdAt: string;
  videoTitle?: string;
  videoAuthorName?: string;
  videoAuthorIconUrl?: string | null;
  uniqueVideoId?: string | null;
}

export interface AppState {
  user: User | null;
  videos: Video[];
  folders: Folder[];
  isLoading: boolean;
  signInUserAction: (email: string, password: string) => Promise<boolean>;
  signUpUserAction: (email: string, password: string, username: string, birthdate?: Date | null) => Promise<string | null>;
  logoutUser: () => Promise<void>;
  addVideo: (video: Omit<Video, 'id' | 'createdAt'>) => Promise<Video>;
  updateVideo: (video: Video) => Promise<Video>;
  removeVideo: (id: string) => Promise<void>;
  addFolder: (name: string) => Promise<Folder>;
  removeFolder: (id: string) => Promise<void>;
  getVideos: () => Promise<Video[]>;
  getFolders: () => Promise<Folder[]>;
  initializeStorage: () => Promise<void>;
}