import { create } from 'zustand';
import { AppState, Video, Folder, User } from '../types';
import {
  signUpUser,
  signInUser,
  signOutUser,
  getCurrentUser,
  getVideos as getSupabaseVideos,
  addVideo as addSupabaseVideo,
  updateVideo as updateSupabaseVideo,
  removeVideo as removeSupabaseVideo,
  getFolders as getSupabaseFolders,
  addFolder as addSupabaseFolder,
  removeFolder as removeSupabaseFolder,
  initializeStorage as initializeSupabaseStorage,
} from '../utils/supabaseStorage';
import { supabase } from '../utils/supabase';

export const useStore = create<AppState>((set, get) => ({
  user: null,
  videos: [],
  folders: [],
  isLoading: true,
  
  signInUserAction: async (email: string, password: string) => {
    console.log('[DEBUG] signInUserAction: Starting sign in process');
    try {
      console.log('[DEBUG] signInUserAction: Calling signInUser with email:', email);
      const { user: signedInUser, error: signInError } = await signInUser(email, password);
      console.log('[DEBUG] signInUserAction: signInUser result:', {
        hasUser: !!signedInUser,
        hasError: !!signInError,
        error: signInError,
        username: signedInUser?.username
      });
      
      if (signedInUser && !signInError) {
        console.log('[DEBUG] signInUserAction: Sign in successful, initializing storage');
        await initializeSupabaseStorage();
        console.log('[DEBUG] signInUserAction: Storage initialized, loading data');
        const videos = await getSupabaseVideos();
        const folders = await getSupabaseFolders();
        console.log('[DEBUG] signInUserAction: Data loaded, updating state');
        set({ user: signedInUser, videos, folders, isLoading: false });
        console.log('[DEBUG] signInUserAction: State updated successfully');
        return true;
      }
      
      console.log('[DEBUG] signInUserAction: Sign in failed');
      return false;
    } catch (error) {
      console.error('[DEBUG] signInUserAction: Exception occurred:', error);
      console.error('[DEBUG] signInUserAction: Exception stack:', error instanceof Error ? error.stack : 'No stack trace');
      return false;
    }
  },
  
  signUpUserAction: async (email: string, password: string, username: string, birthdate?: Date | null) => {
    try {
      console.log('[DEBUG] signUpUserAction: Starting sign up process', {
        email,
        username,
        hasBirthdate: !!birthdate
      });
      const { user: signedUpUser, error: signUpError } = await signUpUser(email, password, username, birthdate);
      console.log('[DEBUG] signUpUserAction: signUpUser result:', {
        hasUser: !!signedUpUser,
        hasError: !!signUpError,
        error: signUpError
      });
      
      if (signedUpUser && !signUpError) {
        console.log('[DEBUG] signUpUserAction: Sign up successful, initializing storage');
        await initializeSupabaseStorage();
        const videos = await getSupabaseVideos();
        const folders = await getSupabaseFolders();
        set({ user: signedUpUser, videos, folders, isLoading: false });
        console.log('[DEBUG] signUpUserAction: Sign up completed successfully');
        return null; // Success
      }
      
      console.log('[DEBUG] signUpUserAction: Sign up failed:', signUpError);
      return signUpError || 'アカウント作成に失敗しました';
    } catch (error) {
      console.error('[DEBUG] signUpUserAction: Exception occurred:', error);
      console.error('[DEBUG] signUpUserAction: Exception stack:', error instanceof Error ? error.stack : 'No stack trace');
      return error instanceof Error ? error.message : 'アカウント作成中にエラーが発生しました';
    }
  },
  
  logoutUser: async () => {
    await signOutUser();
    set({ user: null, videos: [], folders: [], isLoading: false });
  },
  
  addVideo: async (videoData) => {
    try {
      const newVideo = await addSupabaseVideo(videoData);
      set(state => ({ videos: [...state.videos, newVideo] }));
      return newVideo;
    } catch (error) {
      console.error('Add video error:', error);
      throw error;
    }
  },
  
  updateVideo: async (updatedVideo: Video) => {
    try {
      const video = await updateSupabaseVideo(updatedVideo);
      set(state => ({
        videos: state.videos.map(v =>
          v.id === video.id ? video : v
        )
      }));
      return video;
    } catch (error) {
      console.error('Update video error:', error);
      throw error;
    }
  },
  
  removeVideo: async (id: string) => {
    try {
      await removeSupabaseVideo(id);
      set(state => ({ videos: state.videos.filter(video => video.id !== id) }));
    } catch (error) {
      console.error('Remove video error:', error);
      throw error;
    }
  },
  
  addFolder: async (name: string) => {
    try {
      const newFolder = await addSupabaseFolder(name);
      set(state => ({ folders: [...state.folders, newFolder] }));
      return newFolder;
    } catch (error) {
      console.error('Add folder error:', error);
      throw error;
    }
  },
  
  removeFolder: async (id: string) => {
    try {
      await removeSupabaseFolder(id);
      const folders = await getSupabaseFolders();
      const videos = await getSupabaseVideos();
      set({ folders, videos });
    } catch (error) {
      console.error('Remove folder error:', error);
      throw error;
    }
  },
  
  getVideos: async () => {
    try {
      const videos = await getSupabaseVideos();
      set({ videos });
      return videos;
    } catch (error) {
      console.error('Get videos error:', error);
      return [];
    }
  },
  
  getFolders: async () => {
    try {
      const folders = await getSupabaseFolders();
      set({ folders });
      return folders;
    } catch (error) {
      console.error('Get folders error:', error);
      return [];
    }
  },

  initializeStorage: async () => {
    await initializeSupabaseStorage();
  }
}));

export async function initializeAppState() {
  console.log('[DEBUG] initializeAppState: Starting initialization');
  console.log('[DEBUG] initializeAppState: Timestamp:', new Date().toISOString());
  console.log('[DEBUG] initializeAppState: Environment check:', {
    hasSupabaseUrl: !!process.env.EXPO_PUBLIC_SUPABASE_URL,
    hasSupabaseKey: !!process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY
  });
  
  try {
    // Check for existing session
    console.log('[DEBUG] initializeAppState: Calling supabase.auth.getSession()');
    const { data: { session } } = await supabase.auth.getSession();
    console.log('[DEBUG] initializeAppState: Session check result:', {
      hasSession: !!session,
      hasUser: !!session?.user,
      userId: session?.user?.id,
      sessionExpiry: session?.expires_at,
      accessToken: session?.access_token ? 'Present' : 'Missing'
    });
    
    if (session?.user) {
      console.log('[DEBUG] initializeAppState: Session found, calling getCurrentUser()');
      const user = await getCurrentUser();
      console.log('[DEBUG] initializeAppState: getCurrentUser result:', {
        hasUser: !!user,
        username: user?.username,
        isLoggedIn: user?.isLoggedIn
      });
      
      if (user) {
        console.log('[DEBUG] initializeAppState: User found, initializing storage');
        await initializeSupabaseStorage();
        console.log('[DEBUG] initializeAppState: Storage initialized, loading data');
        
        console.log('[DEBUG] initializeAppState: Calling getSupabaseVideos()');
        const videos = await getSupabaseVideos();
        console.log('[DEBUG] initializeAppState: Videos loaded:', {
          count: videos.length,
          firstVideoId: videos[0]?.id
        });
        
        console.log('[DEBUG] initializeAppState: Calling getSupabaseFolders()');
        const folders = await getSupabaseFolders();
        console.log('[DEBUG] initializeAppState: Data loaded:', {
          videosCount: videos.length,
          foldersCount: folders.length
        });
        
        console.log('[DEBUG] initializeAppState: Updating store state with user data');
        useStore.setState({
          user,
          videos,
          folders,
          isLoading: false
        });
        console.log('[DEBUG] initializeAppState: State updated with user data');
        console.log('[DEBUG] initializeAppState: Final state check:', {
          storeUser: useStore.getState().user?.username,
          storeVideosCount: useStore.getState().videos.length,
          storeFoldersCount: useStore.getState().folders.length,
          storeIsLoading: useStore.getState().isLoading
        });
        return true;
      }
    }
    
    console.log('[DEBUG] initializeAppState: No valid session/user, setting isLoading to false');
    useStore.setState({ isLoading: false });
    console.log('[DEBUG] initializeAppState: No session, set isLoading to false');
    return false;
  } catch (error) {
    console.error('[DEBUG] initializeAppState: Error occurred:', error);
    console.error('[DEBUG] initializeAppState: Error stack:', error instanceof Error ? error.stack : 'No stack trace');
    useStore.setState({ isLoading: false });
    console.log('[DEBUG] initializeAppState: Error occurred, set isLoading to false');
    return false;
  }
}

// Listen for auth state changes
supabase.auth.onAuthStateChange(async (event, session) => {
  console.log('[DEBUG] Auth state change:', { 
    event, 
    hasSession: !!session, 
    hasUser: !!session?.user,
    userId: session?.user?.id,
    timestamp: new Date().toISOString()
  });
  
  if (event === 'SIGNED_OUT' || !session) {
    console.log('[DEBUG] Auth state change: Processing sign out');
    useStore.setState({ user: null, videos: [], folders: [], isLoading: false });
    console.log('[DEBUG] Auth state change: User signed out, cleared state');
  } else if (event === 'SIGNED_IN' && session.user) {
    console.log('[DEBUG] Auth state change: Processing sign in, calling getCurrentUser()');
    const user = await getCurrentUser();
    console.log('[DEBUG] Auth state change: User signed in, got user:', user);
    if (user) {
      console.log('[DEBUG] Auth state change: Initializing storage and loading data');
      await initializeSupabaseStorage();
      const videos = await getSupabaseVideos();
      const folders = await getSupabaseFolders();
      console.log('[DEBUG] Auth state change: Data loaded, updating state');
      useStore.setState({ user, videos, folders, isLoading: false });
      console.log('[DEBUG] Auth state change: Updated state with user data');
    }
  }
});