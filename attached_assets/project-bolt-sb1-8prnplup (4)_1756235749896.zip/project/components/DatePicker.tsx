import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput } from 'react-native';

interface DatePickerProps {
  label: string;
  value: Date | null;
  onChange: (date: Date | null) => void;
  mode?: 'date' | 'time' | 'datetime';
  format?: string;
}

export default function DatePicker({
  label,
  value,
  onChange,
}: DatePickerProps) {
  const [textValue, setTextValue] = useState(
    value ? formatDateToEightDigits(value) : ''
  );

  const formatDateToEightDigits = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}${month}${day}`;
  };

  const parseEightDigitsToDate = (text: string): Date | null => {
    // Remove any non-digit characters
    const digits = text.replace(/\D/g, '');
    
    if (digits.length !== 8) {
      return null;
    }

    const year = parseInt(digits.substring(0, 4));
    const month = parseInt(digits.substring(4, 6));
    const day = parseInt(digits.substring(6, 8));

    // Basic validation
    if (year < 1900 || year > new Date().getFullYear()) {
      return null;
    }
    if (month < 1 || month > 12) {
      return null;
    }
    if (day < 1 || day > 31) {
      return null;
    }

    const date = new Date(year, month - 1, day);
    
    // Check if the date is valid and not in the future
    if (date.getFullYear() !== year || 
        date.getMonth() !== month - 1 || 
        date.getDate() !== day ||
        date > new Date()) {
      return null;
    }

    return date;
  };

  const handleTextChange = (text: string) => {
    // Only allow digits and limit to 8 characters
    const digits = text.replace(/\D/g, '').substring(0, 8);
    setTextValue(digits);
    
    const parsedDate = parseEightDigitsToDate(digits);
    onChange(parsedDate);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        value={textValue}
        onChangeText={handleTextChange}
        placeholder="20250101"
        placeholderTextColor="#A3A3A3"
        keyboardType="numeric"
        maxLength={8}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    marginBottom: 8,
    fontWeight: '500',
    color: '#4B4B4B',
  },
  input: {
    backgroundColor: '#F5F5F5',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#1F1F1F',
  },
});