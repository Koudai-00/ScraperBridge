import React from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { ChefHat, Pencil, Trash2, Youtube, Instagram, Video as VideoIcon, MessageCircle, User } from 'lucide-react-native';
import { Video, VideoSource } from '../types';

interface VideoCardProps {
  video: Video;
  folderName: string;
  onDelete?: (id: string) => void;
  onEdit?: (video: Video) => void;
}

export default function VideoCard({ video, folderName, onDelete, onEdit }: VideoCardProps) {
  const router = useRouter();
  
  const renderSourceIcon = () => {
    switch (video.source) {
      case VideoSource.YouTube:
        return <Youtube size={16} color="#FF0000" />;
      case VideoSource.Instagram:
        return <Instagram size={16} color="#E4405F" />;
      case VideoSource.TikTok:
        return <MessageCircle size={16} color="#000000" />;
      default:
        return <VideoIcon size={16} color="#666666" />;
    }
  };

  const renderAuthorIcon = () => {
    if (video.videoAuthorIconUrl) {
      return (
        <Image 
          source={{ uri: video.videoAuthorIconUrl }}
          style={styles.authorIcon}
        />
      );
    }
    
    // Fallback to platform-specific icons
    switch (video.source.toLowerCase()) {
      case 'youtube':
        return <Youtube size={16} color="#FF0000" />;
      case 'instagram':
        return <Instagram size={16} color="#E4405F" />;
      case 'tiktok':
        return <MessageCircle size={16} color="#000000" />;
      default:
        return <User size={16} color="#666666" />;
    }
  };
  const handlePress = () => {
    router.push(`/video/${video.id}`);
  };

  return (
    <TouchableOpacity 
      style={styles.card}
      onPress={handlePress}
    >
      <View style={styles.thumbnailContainer}>
        <Image 
          source={{ uri: video.thumbnailUrl }}
          style={styles.thumbnail}
          resizeMode="cover"
        />
        <View style={styles.sourceIconContainer}>
          {renderSourceIcon()}
        </View>
      </View>
      
      <View style={styles.content}>
        <Text style={styles.title} numberOfLines={1}>
          {video.videoTitle || video.title}
        </Text>
        
        {video.videoAuthorName && (
          <View style={styles.authorContainer}>
            {renderAuthorIcon()}
            <Text style={styles.authorName} numberOfLines={1}>{video.videoAuthorName}</Text>
          </View>
        )}
        
        <View style={styles.metaContainer}>
          <View style={styles.folderBadge}>
            <ChefHat size={12} color="#FF9494" />
            <Text style={styles.folderName} numberOfLines={1}>{folderName}</Text>
          </View>
          
          <Text style={styles.date}>
            {new Date(video.createdAt).toLocaleDateString('ja-JP')}
          </Text>
        </View>
        
        {video.notes ? (
          <Text style={styles.notes} numberOfLines={2}>{video.notes}</Text>
        ) : null}
      </View>
      
      {(onEdit || onDelete) && (
        <View style={styles.actions}>
          {onEdit && (
            <TouchableOpacity 
              style={styles.actionButton} 
              onPress={() => onEdit(video)}
            >
              <Pencil size={16} color="#FF9494" />
            </TouchableOpacity>
          )}
          
          {onDelete && (
            <TouchableOpacity 
              style={styles.actionButton} 
              onPress={() => onDelete(video.id)}
            >
              <Trash2 size={16} color="#FF5252" />
            </TouchableOpacity>
          )}
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    overflow: 'hidden',
    margin: 4,
  },
  thumbnailContainer: {
    position: 'relative',
    width: '100%',
    aspectRatio: 16 / 9,
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  sourceIconContainer: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: 12,
    padding: 4,
  },
  content: {
    padding: 12,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F1F1F',
    marginBottom: 8,
  },
  metaContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  folderBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF0F0',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    maxWidth: '70%',
  },
  folderName: {
    fontSize: 10,
    color: '#FF9494',
    marginLeft: 2,
  },
  date: {
    fontSize: 10,
    color: '#A3A3A3',
  },
  notes: {
    fontSize: 12,
    color: '#4B4B4B',
    marginTop: 4,
  },
  authorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  authorIcon: {
    width: 16,
    height: 16,
    borderRadius: 8,
  },
  authorName: {
    fontSize: 12,
    color: '#666666',
    marginLeft: 4,
    flex: 1,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    padding: 8,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  actionButton: {
    padding: 8,
    marginLeft: 8,
  },
});