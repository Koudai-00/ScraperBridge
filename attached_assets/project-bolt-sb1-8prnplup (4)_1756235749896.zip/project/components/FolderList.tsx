import React from 'react';
import { StyleSheet, Text, View, FlatList, TouchableOpacity } from 'react-native';
import { Folder } from 'lucide-react-native';
import { Folder as FolderType } from '../types';

interface FolderListProps {
  folders: FolderType[];
  selectedFolderId: string | null;
  onSelectFolder: (folderId: string | null) => void;
}

export default function FolderList({ folders, selectedFolderId, onSelectFolder }: FolderListProps) {
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={[
          styles.folderItem,
          selectedFolderId === null ? styles.selectedFolder : null
        ]}
        onPress={() => onSelectFolder(null)}
      >
        <Folder size={16} color={selectedFolderId === null ? '#FFF' : '#FF9494'} />
        <Text 
          style={[
            styles.folderName, 
            selectedFolderId === null ? styles.selectedFolderText : null
          ]}
        >
          すべて
        </Text>
      </TouchableOpacity>
      
      <FlatList
        data={folders}
        keyExtractor={(item) => item.id}
        horizontal
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[
              styles.folderItem,
              selectedFolderId === item.id ? styles.selectedFolder : null
            ]}
            onPress={() => onSelectFolder(item.id)}
          >
            <Folder size={16} color={selectedFolderId === item.id ? '#FFF' : '#FF9494'} />
            <Text 
              style={[
                styles.folderName, 
                selectedFolderId === item.id ? styles.selectedFolderText : null
              ]}
            >
              {item.name}
            </Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  folderItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF0F0',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    marginRight: 8,
  },
  selectedFolder: {
    backgroundColor: '#FF9494',
  },
  folderName: {
    fontSize: 14,
    color: '#FF9494',
    marginLeft: 4,
    fontWeight: '500',
  },
  selectedFolderText: {
    color: 'white',
  },
});