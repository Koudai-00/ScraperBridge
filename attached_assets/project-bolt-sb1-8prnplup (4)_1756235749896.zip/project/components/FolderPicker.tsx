import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { Circle, CircleCheck as CheckCircle2 } from 'lucide-react-native';
import { Folder } from '@/types';

interface FolderPickerProps {
  label: string;
  folders: Folder[];
  selectedFolderId: string;
  onValueChange: (folderId: string) => void;
}

export default function FolderPicker({
  label,
  folders,
  selectedFolderId,
  onValueChange
}: FolderPickerProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.listContainer}>
        {folders.map((folder) => (
          <TouchableOpacity
            key={folder.id}
            style={styles.folderItem}
            onPress={() => onValueChange(folder.id)}
          >
            {selectedFolderId === folder.id ? (
              <CheckCircle2 size={24} color="#FF9494" />
            ) : (
              <Circle size={24} color="#CCCCCC" />
            )}
            <Text style={[
              styles.folderName,
              selectedFolderId === folder.id && styles.selectedFolderName
            ]}>
              {folder.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    marginBottom: 8,
    fontWeight: '500',
    color: '#4B4B4B',
  },
  listContainer: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 12,
    overflow: 'hidden',
  },
  folderItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  folderName: {
    fontSize: 16,
    color: '#1F1F1F',
    marginLeft: 12,
  },
  selectedFolderName: {
    color: '#FF9494',
    fontWeight: '500',
  },
});