import React, { useState } from 'react';
import { StyleSheet, View, Text, Modal, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { X } from 'lucide-react-native';
import { Video, Folder } from '@/types';
import { useStore } from '@/store';
import InputField from './InputField';
import FolderPicker from './FolderPicker';
import Button from './Button';

interface EditVideoModalProps {
  visible: boolean;
  video: Video;
  folder: Folder | undefined;
  onClose: () => void;
  onDelete: () => void;
}

export default function EditVideoModal({
  visible,
  video,
  folder,
  onClose,
  onDelete
}: EditVideoModalProps) {
  const { folders, updateVideo } = useStore();
  
  const [title, setTitle] = useState(video.title);
  const [notes, setNotes] = useState(video.notes);
  const [folderId, setFolderId] = useState(video.folderId);
  const [isLoading, setIsLoading] = useState(false);
  
  const handleSave = async () => {
    if (!title.trim()) {
      Alert.alert('エラー', 'タイトルを入力してください');
      return;
    }
    
    setIsLoading(true);
    try {
      await updateVideo({
        ...video,
        title: title.trim(),
        notes: notes.trim(),
        folderId,
      });
      onClose();
    } catch (error) {
      Alert.alert('エラー', '更新に失敗しました');
    } finally {
      setIsLoading(false);
    }
  };
  
  const confirmDelete = () => {
    Alert.alert(
      '動画を削除',
      'この動画を削除してもよろしいですか？',
      [
        {
          text: 'キャンセル',
          style: 'cancel',
        },
        {
          text: '削除',
          style: 'destructive',
          onPress: onDelete,
        },
      ]
    );
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>動画を編集</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <X size={24} color="#666666" />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.scrollContent}>
            <FolderPicker
              label="保存先フォルダ"
              folders={folders}
              selectedFolderId={folderId}
              onValueChange={setFolderId}
            />
            
            <InputField
              label="タイトル"
              value={title}
              onChangeText={setTitle}
              placeholder="動画のタイトルを入力"
            />
            
            <InputField
              label="メモ"
              value={notes}
              onChangeText={setNotes}
              placeholder="レシピのメモを入力"
              multiline
              numberOfLines={4}
              style={styles.notesInput}
            />
          </ScrollView>
          
          <View style={styles.footer}>
            <Button
              title="キャンセル"
              variant="secondary"
              onPress={onClose}
              style={styles.footerButton}
            />
            <Button
              title="保存"
              onPress={handleSave}
              isLoading={isLoading}
              style={styles.footerButton}
            />
            <Button
              title="削除"
              variant="danger"
              onPress={confirmDelete}
              style={styles.footerButton}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '90%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F1F1F',
  },
  closeButton: {
    padding: 4,
  },
  scrollContent: {
    padding: 20,
  },
  notesInput: {
    height: 120,
    textAlignVertical: 'top',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#EEEEEE',
    gap: 8,
  },
  footerButton: {
    flex: 1,
  },
});