import React from 'react';
import { StyleSheet, View, Text, Modal, TouchableOpacity, ScrollView, Image } from 'react-native';
import { X, Youtube, Instagram, MessageCircle, User } from 'lucide-react-native';
import { Video } from '@/types';
import { formatDate } from '@/utils/dateUtils';

interface VideoDetailModalProps {
  visible: boolean;
  video: Video;
  onClose: () => void;
}

export default function VideoDetailModal({ visible, video, onClose }: VideoDetailModalProps) {
  const renderAuthorIcon = () => {
    if (video.videoAuthorIconUrl) {
      return (
        <Image 
          source={{ uri: video.videoAuthorIconUrl }}
          style={styles.authorIcon}
        />
      );
    }
    
    // Fallback to platform-specific icons
    switch (video.source.toLowerCase()) {
      case 'youtube':
        return <Youtube size={20} color="#FF0000" />;
      case 'instagram':
        return <Instagram size={20} color="#E4405F" />;
      case 'tiktok':
        return <MessageCircle size={20} color="#000000" />;
      default:
        return <User size={20} color="#666666" />;
    }
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>レシピ詳細</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <X size={24} color="#666666" />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.scrollContent}>
            <View style={styles.section}>
              <Text style={styles.label}>タイトル</Text>
              <Text style={styles.text}>
                {video.videoTitle || video.title}
              </Text>
            </View>
            
            {video.videoAuthorName && (
              <View style={styles.section}>
                <Text style={styles.label}>投稿者</Text>
                <View style={styles.authorContainer}>
                  {renderAuthorIcon()}
                  <Text style={styles.authorText}>{video.videoAuthorName}</Text>
                </View>
              </View>
            )}
            
            {video.notes && (
              <View style={styles.section}>
                <Text style={styles.label}>メモ</Text>
                <Text style={styles.text}>{video.notes}</Text>
              </View>
            )}
            
            <View style={styles.section}>
              <Text style={styles.label}>保存日</Text>
              <Text style={styles.text}>
                {formatDate(new Date(video.createdAt))}
              </Text>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '80%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F1F1F',
  },
  closeButton: {
    padding: 4,
  },
  scrollContent: {
    padding: 20,
  },
  section: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 8,
  },
  text: {
    fontSize: 16,
    color: '#1F1F1F',
    lineHeight: 24,
  },
  authorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  authorIcon: {
    width: 20,
    height: 20,
    borderRadius: 10,
  },
  authorText: {
    fontSize: 16,
    color: '#1F1F1F',
    marginLeft: 8,
    flex: 1,
  },
});