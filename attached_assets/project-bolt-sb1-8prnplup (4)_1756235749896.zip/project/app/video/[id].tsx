import React, { useState, useCallback } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Share, Platform } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { WebView } from 'react-native-webview';
import YoutubePlayer from 'react-native-youtube-iframe';
import * as WebBrowser from 'expo-web-browser';
import { MoreVertical, ExternalLink, Share2, Pencil, ArrowLeft } from 'lucide-react-native';
import { useStore } from '@/store';
import VideoDetailModal from '@/components/VideoDetailModal';
import EditVideoModal from '@/components/EditVideoModal';
import { getVideoSource, getYoutubeVideoId } from '@/utils/videoUtils';
import { VideoSource } from '@/types';

export default function VideoDetailScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { videos, folders, removeVideo } = useStore();
  
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  
  const video = videos.find(v => v.id === id);
  const folder = folders.find(f => f.id === video?.folderId);
  
  if (!video) {
    return (
      <View style={styles.container}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color="white" />
        </TouchableOpacity>
        <View style={styles.centerContent}>
          <Text style={styles.errorText}>動画が見つかりません</Text>
        </View>
      </View>
    );
  }

  const videoSource = getVideoSource(video.url);
  const youtubeVideoId = videoSource === VideoSource.YouTube ? getYoutubeVideoId(video.url) : null;
  
  const handleExternalLink = async () => {
    await WebBrowser.openBrowserAsync(video.url);
  };
  
  const handleShare = async () => {
    try {
      await Share.share({
        title: video.title,
        message: `${video.title}\n${video.notes || ''}\n\n${video.url}`,
      });
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };
  
  const handleDelete = async () => {
    await removeVideo(video.id);
    router.back();
  };

  const renderVideoPlayer = () => {
    if (videoSource === VideoSource.YouTube && youtubeVideoId) {
      return (
        <YoutubePlayer
          height={300}
          videoId={youtubeVideoId}
          play={true}
          webViewProps={{
            renderToHardwareTextureAndroid: true,
          }}
        />
      );
    }

    return (
      <WebView
        source={{ uri: video.url }}
        style={styles.video}
        allowsFullscreenVideo
        javaScriptEnabled
      />
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color="white" />
        </TouchableOpacity>
        
        <Text style={styles.headerTitle} numberOfLines={1}>
          {video.title}
        </Text>
      </View>

      <View style={styles.videoContainer}>
        {renderVideoPlayer()}
      </View>
      
      <View style={styles.actionBar}>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => setShowDetailModal(true)}
        >
          <MoreVertical size={24} color="#333333" />
          <Text style={styles.actionText}>詳細</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.actionButton}
          onPress={handleExternalLink}
        >
          <ExternalLink size={24} color="#333333" />
          <Text style={styles.actionText}>開く</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.actionButton}
          onPress={handleShare}
        >
          <Share2 size={24} color="#333333" />
          <Text style={styles.actionText}>共有</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => setShowEditModal(true)}
        >
          <Pencil size={24} color="#333333" />
          <Text style={styles.actionText}>編集</Text>
        </TouchableOpacity>
      </View>
      
      <VideoDetailModal
        visible={showDetailModal}
        video={video}
        onClose={() => setShowDetailModal(false)}
      />
      
      <EditVideoModal
        visible={showEditModal}
        video={video}
        folder={folder}
        onClose={() => setShowEditModal(false)}
        onDelete={handleDelete}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    color: 'white',
    fontSize: 16,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 60 : 20,
    paddingBottom: 16,
    paddingHorizontal: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 10,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  headerTitle: {
    flex: 1,
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
    marginRight: 56, // To center the title accounting for back button
  },
  videoContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  video: {
    flex: 1,
  },
  actionBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: 'white',
    paddingVertical: 12,
    paddingBottom: Platform.OS === 'ios' ? 40 : 12,
  },
  actionButton: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
  },
  actionText: {
    marginTop: 4,
    fontSize: 12,
    color: '#333333',
  },
});