import React, { useEffect, useState } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  FlatList, 
  SafeAreaView, 
  ActivityIndicator, 
  RefreshControl,
  Dimensions,
  Pressable,
  Modal
} from 'react-native';
import { useRouter } from 'expo-router';
import { Video, VideoSource, Folder } from '@/types';
import { useStore } from '@/store';
import VideoCard from '@/components/VideoCard';
import FolderList from '@/components/FolderList';
import Button from '@/components/Button';
import InputField from '@/components/InputField';
import { SearchX, ChevronDown } from 'lucide-react-native';

type SortOption = 'relevance' | 'newest' | 'oldest';

interface FilterState {
  folderId: string;
  source: string;
}

interface DropdownProps {
  label: string;
  value: string;
  options: { label: string; value: string }[];
  onChange: (value: string) => void;
}

function Dropdown({ label, value, options, onChange }: DropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const selectedOption = options.find(opt => opt.value === value) || options[0];

  return (
    <View style={styles.pickerWrapper}>
      <Text style={styles.pickerLabel}>{label}</Text>
      <Pressable
        style={styles.pickerContainer}
        onPress={() => setIsOpen(true)}
      >
        <Text style={styles.pickerText}>{selectedOption.label}</Text>
        <ChevronDown size={16} color="#666666" />
      </Pressable>

      <Modal
        visible={isOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setIsOpen(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setIsOpen(false)}
        >
          <View style={styles.modalContent}>
            {options.map((option) => (
              <Pressable
                key={option.value}
                style={[
                  styles.modalOption,
                option.value === value && styles.modalOptionSelected
                ]}
                onPress={() => {
                  onChange(option.value);
                  setIsOpen(false);
                }}
              >
                <Text style={[
                  styles.modalOptionText,
                  option.value === value && styles.modalOptionTextSelected
                ]}>
                  {option.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

export default function HomeScreen() {
  const router = useRouter();
  const { user, videos, folders, getVideos, getFolders } = useStore();
  
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('relevance');
  const [filters, setFilters] = useState<FilterState>({
    folderId: '',
    source: '',
  });
  
  useEffect(() => {
    loadData();
  }, []);
  
  const loadData = async () => {
    setIsLoading(true);
    try {
      await Promise.all([getVideos(), getFolders()]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const searchVideos = (query: string, videos: Video[]): Video[] => {
    let filteredVideos = videos.filter(video => {
      if (filters.folderId && video.folderId !== filters.folderId) return false;
      if (filters.source && video.source !== filters.source) return false;
      return true;
    });
    
    if (!query.trim()) return filteredVideos;
    
    const keywords = query.toLowerCase().split(' ').filter(k => k.length > 0);
    return filteredVideos.filter(video => 
      keywords.every(keyword =>
        video.title.toLowerCase().includes(keyword) ||
        (video.notes && video.notes.toLowerCase().includes(keyword))
      )
    );
  };

  const sortVideos = (videos: Video[]): Video[] => {
    const sorted = [...videos];
    
    switch (sortOption) {
      case 'newest':
        return sorted.sort((a, b) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
      case 'oldest':
        return sorted.sort((a, b) => 
          new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        );
      case 'relevance':
      default:
        return sorted;
    }
  };

  const searchResults = sortVideos(searchVideos(searchQuery, videos));
  
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FF9494" />
      </View>
    );
  }
  
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>料理動画コレクション</Text>
        <Text style={styles.username}>{user?.username}さん</Text>
      </View>

      <View style={styles.searchContainer}>
        <InputField
          label=""
          placeholder="キーワードを入力（スペース区切りで複数検索）"
          value={searchQuery}
          onChangeText={setSearchQuery}
          style={styles.searchInput}
        />
      </View>

      <View style={styles.filterContainer}>
        <Dropdown
          label="保存先フォルダ"
          value={filters.folderId}
          options={[
            { label: 'すべて', value: '' },
            ...folders.map(folder => ({
              label: folder.name,
              value: folder.id
            }))
          ]}
          onChange={(value) => setFilters(prev => ({ ...prev, folderId: value }))}
        />

        <Dropdown
          label="動画ソース"
          value={filters.source}
          options={[
            { label: 'すべて', value: '' },
            ...Object.values(VideoSource).map(source => ({
              label: source,
              value: source
            }))
          ]}
          onChange={(value) => setFilters(prev => ({ ...prev, source: value }))}
        />

        <Dropdown
          label="並び替え"
          value={sortOption}
          options={[
            { label: '関連度順', value: 'relevance' },
            { label: '保存日時が新しい順', value: 'newest' },
            { label: '保存日時が古い順', value: 'oldest' }
          ]}
          onChange={(value) => setSortOption(value as SortOption)}
        />
      </View>
      
      {searchResults.length > 0 ? (
        <FlatList
          data={searchResults}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={styles.columnWrapper}
          renderItem={({ item }) => (
            <VideoCard 
              video={item} 
              folderName={folders.find(f => f.id === item.folderId)?.name || '未分類'} 
            />
          )}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              colors={['#FF9494']}
              tintColor="#FF9494"
            />
          }
        />
      ) : (
        <View style={styles.emptyContainer}>
          <SearchX size={64} color="#DDDDDD" />
          <Text style={styles.emptyText}>表示できるレシピがありません</Text>
          <Button
            title="動画を追加する"
            onPress={() => router.push('/(tabs)/add-video')}
            style={styles.addButton}
          />
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    padding: 16,
    paddingTop: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F1F1F',
    marginBottom: 4,
  },
  username: {
    fontSize: 14,
    color: '#6B6B6B',
  },
  searchContainer: {
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  filterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    gap: 8,
  },
  pickerWrapper: {
    flex: 1,
  },
  pickerLabel: {
    fontSize: 12,
    color: '#666666',
    marginBottom: 4,
  },
  pickerContainer: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pickerText: {
    fontSize: 14,
    color: '#333333',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    width: '80%',
    maxHeight: '80%',
  },
  modalOption: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  modalOptionSelected: {
    backgroundColor: '#FFF0F0',
  },
  modalOptionText: {
    fontSize: 16,
    color: '#333333',
  },
  modalOptionTextSelected: {
    color: '#FF9494',
    fontWeight: '500',
  },
  listContent: {
    padding: 8,
    paddingBottom: 24,
  },
  columnWrapper: {
    justifyContent: 'space-between',
    padding: 8,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyText: {
    marginTop: 16,
    fontSize: 16,
    color: '#6B6B6B',
    textAlign: 'center',
  },
  addButton: {
    marginTop: 24,
    width: 200,
  },
});