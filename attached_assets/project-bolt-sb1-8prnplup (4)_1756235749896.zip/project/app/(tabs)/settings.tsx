import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  SafeAreaView,
  TouchableOpacity,
  Alert,
  TextInput,
  Modal
} from 'react-native';
import { useRouter } from 'expo-router';
import Button from '@/components/Button';
import { useStore } from '@/store';
import { Plus, Trash, FolderPlus, LogOut, ChefHat } from 'lucide-react-native';

export default function SettingsScreen() {
  const router = useRouter();
  const { user, folders, getFolders, addFolder, removeFolder, logoutUser } = useStore();
  
  const [newFolderName, setNewFolderName] = useState('');
  const [isAddingFolder, setIsAddingFolder] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  
  useEffect(() => {
    getFolders();
  }, []);
  
  const handleAddFolder = async () => {
    if (!newFolderName.trim()) {
      Alert.alert('エラー', 'フォルダ名を入力してください');
      return;
    }
    
    try {
      await addFolder(newFolderName.trim());
      setNewFolderName('');
      setModalVisible(false);
    } catch (error) {
      Alert.alert('エラー', 'フォルダの作成に失敗しました');
    }
  };
  
  const handleRemoveFolder = (id: string, name: string) => {
    Alert.alert(
      'フォルダを削除',
      `"${name}"フォルダを削除しますか？含まれる動画は「未分類」フォルダに移動されます。`,
      [
        {
          text: 'キャンセル',
          style: 'cancel',
        },
        {
          text: '削除',
          style: 'destructive',
          onPress: async () => {
            try {
              await removeFolder(id);
            } catch (error) {
              Alert.alert('エラー', 'フォルダの削除に失敗しました');
            }
          },
        },
      ]
    );
  };
  
  const handleLogout = () => {
    const performLogout = async () => {
      try {
        await logoutUser();
        router.replace('/(auth)/login');
      } catch (error) {
        console.error('Logout error:', error);
      }
    };
    
    performLogout();
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <Text style={styles.title}>設定</Text>
          <Text style={styles.username}>{user?.username}さん</Text>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleContainer}>
              <ChefHat size={20} color="#FF9494" />
              <Text style={styles.sectionTitle}>フォルダ管理</Text>
            </View>
            
            <TouchableOpacity
              style={styles.addButton}
              onPress={() => setModalVisible(true)}
            >
              <FolderPlus size={20} color="#FF9494" />
            </TouchableOpacity>
          </View>
          
          <Text style={styles.sectionDesc}>
            動画を整理するフォルダを作成・削除できます。
          </Text>
          
          <View style={styles.folderList}>
            {folders.map((folder) => (
              <View key={folder.id} style={styles.folderItem}>
                <ChefHat size={16} color="#FF9494" />
                <Text style={styles.folderName}>{folder.name}</Text>
                <TouchableOpacity
                  style={styles.folderDeleteButton}
                  onPress={() => handleRemoveFolder(folder.id, folder.name)}
                  // Disable deletion of "Uncategorized" folder
                  disabled={folder.name === '未分類'}
                >
                  <Trash size={16} color={folder.name === '未分類' ? '#CCCCCC' : '#FF5252'} />
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleContainer}>
              <LogOut size={20} color="#FF9494" />
              <Text style={styles.sectionTitle}>アカウント</Text>
            </View>
          </View>
          
          <Button
            title="ログアウト"
            variant="danger"
            onPress={handleLogout}
            style={styles.logoutButton}
          />
        </View>
        
        <Modal
          animationType="fade"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>新しいフォルダ</Text>
              
              <TextInput
                style={styles.modalInput}
                placeholder="フォルダ名を入力"
                value={newFolderName}
                onChangeText={setNewFolderName}
                autoFocus
              />
              
              <View style={styles.modalButtons}>
                <Button
                  title="キャンセル"
                  variant="secondary"
                  onPress={() => setModalVisible(false)}
                  style={styles.modalButton}
                />
                <Button
                  title="作成"
                  onPress={handleAddFolder}
                  style={styles.modalButton}
                />
              </View>
            </View>
          </View>
        </Modal>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  scrollContainer: {
    flexGrow: 1,
    paddingBottom: 40,
  },
  header: {
    padding: 16,
    paddingTop: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F1F1F',
    marginBottom: 4,
  },
  username: {
    fontSize: 14,
    color: '#6B6B6B',
  },
  section: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    margin: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F1F1F',
    marginLeft: 8,
  },
  sectionDesc: {
    fontSize: 14,
    color: '#6B6B6B',
    marginBottom: 16,
  },
  addButton: {
    padding: 8,
  },
  folderList: {
    marginTop: 8,
  },
  folderItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  folderName: {
    flex: 1,
    fontSize: 16,
    color: '#1F1F1F',
    marginLeft: 8,
  },
  folderDeleteButton: {
    padding: 8,
  },
  logoutButton: {
    marginTop: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 24,
    width: '80%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F1F1F',
    marginBottom: 16,
    textAlign: 'center',
  },
  modalInput: {
    backgroundColor: '#F5F5F5',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  modalButton: {
    flex: 1,
    marginHorizontal: 4,
  },
});