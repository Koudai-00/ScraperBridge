import React, { useState, useEffect } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  SafeAreaView, 
  ScrollView, 
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useStore } from '@/store';
import VideoCard from '@/components/VideoCard';
import { Video, VideoSource } from '@/types';
import { getYoutubeVideoId } from '@/utils/videoUtils';

const CATEGORIES = [
  { id: 'all', name: 'すべて', keywords: [] },
  { id: 'main', name: '主食', keywords: ['米', '麺類', 'ご飯', '丼', 'うどん', 'パスタ', '主食'] },
  { id: 'side', name: '副菜', keywords: ['副菜', 'みそ汁', 'スープ'] },
  { id: 'japanese', name: '和食', keywords: ['和食', '煮物'] },
  { id: 'western', name: '洋食', keywords: ['洋食'] },
  { id: 'chinese', name: '中華', keywords: ['中華', '中華料理'] },
  { id: 'italian', name: 'イタリア料理', keywords: ['イタリア', 'イタリア料理', 'イタリアン'] },
  { id: 'french', name: 'フランス料理', keywords: ['フランス', 'フレンチ', 'フランス料理'] },
  { id: 'dessert', name: 'デザート', keywords: ['お菓子', 'デザート'] },
  { id: 'fried', name: '揚げ物', keywords: ['揚げ物', '揚げ', 'てんぷら', 'フライ', 'から揚げ', '唐揚げ', 'からあげ', 'コロッケ'] },
  { id: 'simmered', name: '煮物', keywords: ['にもの', '煮物', '煮'] },
  { id: 'other', name: 'その他', keywords: ['さばき方', '捌き方', 'さばく', '下ごしらえ', '下処理'] }
];

interface RankingItem {
  url: string;
  count: number;
  videos: Video[];
}

export default function RankingScreen() {
  const { videos } = useStore();
  const [selectedCategory, setSelectedCategory] = useState(CATEGORIES[0]);
  const [rankings, setRankings] = useState<RankingItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    calculateRankings();
  }, [videos, selectedCategory]);

  const calculateRankings = () => {
    setIsLoading(true);
    
    const filteredVideos = selectedCategory.id === 'all' 
      ? videos
      : videos.filter(video => {
          const searchText = `${video.title} ${video.notes}`.toLowerCase();
          return selectedCategory.keywords.some(keyword => 
            searchText.includes(keyword.toLowerCase())
          );
        });

    const groupedVideos = filteredVideos.reduce((acc, video) => {
      let key = video.url;
      if (video.source === VideoSource.YouTube) {
        const videoId = getYoutubeVideoId(video.url);
        if (videoId) key = videoId;
      }
      
      if (!acc[key]) {
        acc[key] = {
          url: video.url,
          count: 0,
          videos: []
        };
      }
      
      acc[key].count++;
      acc[key].videos.push(video);
      
      return acc;
    }, {} as Record<string, RankingItem>);

    const sortedRankings = Object.values(groupedVideos)
      .sort((a, b) => b.count - a.count)
      .slice(0, 100);

    setRankings(sortedRankings);
    setIsLoading(false);
  };

  const renderRankingItem = ({ item, index }: { item: RankingItem; index: number }) => {
    const video = item.videos[0];
    return (
      <View style={styles.rankingItem}>
        <View style={styles.rankBadge}>
          <Text style={styles.rankText}>#{index + 1}</Text>
        </View>
        <VideoCard
          video={video}
          folderName={`${item.count}人が保存`}
        />
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>人気レシピランキング</Text>
        <Text style={styles.subtitle}>みんなが保存している料理動画ランキング</Text>
      </View>

      <View style={styles.categoryWrapper}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoryContainer}
        >
          {CATEGORIES.map(category => (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryButton,
                selectedCategory.id === category.id && styles.categoryButtonActive
              ]}
              onPress={() => setSelectedCategory(category)}
            >
              <Text style={[
                styles.categoryText,
                selectedCategory.id === category.id && styles.categoryTextActive
              ]}>
                {category.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF9494" />
        </View>
      ) : (
        <FlatList
          data={rankings}
          renderItem={renderRankingItem}
          keyExtractor={(item, index) => `${item.url}-${index}`}
          contentContainerStyle={styles.rankingList}
          numColumns={2}
          columnWrapperStyle={styles.columnWrapper}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>
                このカテゴリーにはまだ動画がありません
              </Text>
            </View>
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    padding: 16,
    paddingTop: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F1F1F',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#6B6B6B',
  },
  categoryWrapper: {
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  categoryContainer: {
    paddingHorizontal: 12,
    paddingVertical: 12,
    gap: 8,
  },
  categoryButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    marginRight: 8,
  },
  categoryButtonActive: {
    backgroundColor: '#FF9494',
  },
  categoryText: {
    fontSize: 14,
    color: '#666666',
  },
  categoryTextActive: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rankingList: {
    padding: 8,
  },
  columnWrapper: {
    justifyContent: 'space-between',
    padding: 8,
  },
  rankingItem: {
    width: '48%',
    marginBottom: 16,
    position: 'relative',
  },
  rankBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: '#FF9494',
    borderRadius: 12,
    padding: 4,
    paddingHorizontal: 8,
    zIndex: 1,
  },
  rankText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  emptyContainer: {
    padding: 32,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#666666',
    textAlign: 'center',
  },
});