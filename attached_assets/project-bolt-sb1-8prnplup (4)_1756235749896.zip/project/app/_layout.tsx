import React, { useEffect } from 'react';
import { Platform, NativeModules } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { initializeAppState } from '@/store';

export default function RootLayout() {
  useFrameworkReady();

  useEffect(() => {
    // Set locale for iOS
    if (Platform.OS === 'ios' && NativeModules.SettingsManager && NativeModules.SettingsManager.settings) {
      NativeModules.SettingsManager.settings.AppleLocale = 'ja_JP';
    }
    
    // Initialize app state when the app loads
    initializeAppState();
  }, []);

  return (
    <>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="(auth)/login" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen 
          name="video/[id]" 
          options={{
            presentation: 'fullScreenModal',
            animation: 'fade',
          }}
        />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style="auto" />
    </>
  );
}