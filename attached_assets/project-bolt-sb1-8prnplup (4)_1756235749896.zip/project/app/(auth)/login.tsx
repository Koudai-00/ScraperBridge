import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  Alert
} from 'react-native';
import { useRouter } from 'expo-router';
import InputField from '@/components/InputField';
import Button from '@/components/Button';
import { useStore } from '@/store';
import DatePicker from '@/components/DatePicker';
import { generateRandomUsername } from '@/utils/auth';

type Tab = 'login' | 'signup';

export default function AuthScreen() {
  const router = useRouter();
  const { signInUserAction, signUpUserAction } = useStore();
  
  const [activeTab, setActiveTab] = useState<Tab>('login');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Login state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Signup state
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [birthDate, setBirthDate] = useState<Date | null>(null);
  
  const validateUsername = (value: string): boolean => {
    if (!value) return true; // Optional field
    const usernameRegex = /^[a-zA-Z0-9._-]+$/;
    return usernameRegex.test(value);
  };
  
  const handleSignup = async () => {
    setError(null);
    
    if (!email) {
      setError('メールアドレスを入力してください');
      return;
    }
    
    if (!password || !confirmPassword) {
      setError('パスワードを入力してください');
      return;
    }
    
    if (password !== confirmPassword) {
      setError('パスワードが一致しません');
      return;
    }
    
    if (username && !validateUsername(username)) {
      setError('ユーザー名には英数字、ピリオド、ハイフン、アンダースコアのみ使用できます');
      return;
    }
    
    setIsLoading(true);
    
    try {
      const finalUsername = username.trim() || ''; // Let the backend handle empty username
      const result = await signUpUserAction(email, password, finalUsername, birthDate);
      
      if (result === null) {
        router.replace('/(tabs)');
      } else {
        // Display the specific error message from Supabase
        setError(result);
      }
    } catch (err) {
      console.error('[DEBUG] handleSignup: Exception in UI:', err);
      setError(`エラーが発生しました: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleLogin = async () => {
    console.log('[DEBUG] handleLogin: Starting login process');
    setError(null);
    
    if (!loginEmail) {
      console.log('[DEBUG] handleLogin: Email validation failed');
      setError('メールアドレスを入力してください');
      return;
    }
    
    if (!loginPassword) {
      console.log('[DEBUG] handleLogin: Password validation failed');
      setError('パスワードを入力してください');
      return;
    }
    
    console.log('[DEBUG] handleLogin: Validation passed, attempting login with email:', loginEmail);
    setIsLoading(true);
    
    try {
      console.log('[DEBUG] handleLogin: Calling signInUserAction');
      const success = await signInUserAction(loginEmail, loginPassword);
      console.log('[DEBUG] handleLogin: signInUserAction result:', success);
      
      if (success) {
        console.log('[DEBUG] handleLogin: Login successful, redirecting to tabs');
        router.replace('/(tabs)');
      } else {
        console.log('[DEBUG] handleLogin: Login failed');
        setError('ログインに失敗しました');
      }
    } catch (err) {
      console.error('[DEBUG] handleLogin: Exception occurred:', err);
      setError('エラーが発生しました');
    } finally {
      setIsLoading(false);
      console.log('[DEBUG] handleLogin: Login process completed');
    }
  };
  
  const useDemoAccount = () => {
    setLoginEmail('demo@example.com');
    setLoginPassword('demo123');
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
      >
        <ScrollView 
          contentContainerStyle={styles.scrollContainer}
          keyboardShouldPersistTaps="handled"
        >
            <View style={styles.header}>
              <Text style={styles.title}>料理動画コレクター</Text>
              <Text style={styles.subtitle}>
                お気に入りのレシピ動画をどこからでも保存
              </Text>
            </View>
            
            <View style={styles.card}>
              <View style={styles.tabs}>
                <TouchableOpacity
                  style={[
                    styles.tab,
                    activeTab === 'signup' && styles.activeTab
                  ]}
                  onPress={() => setActiveTab('signup')}
                >
                  <Text style={[
                    styles.tabText,
                    activeTab === 'signup' && styles.activeTabText
                  ]}>
                    新規登録
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={[
                    styles.tab,
                    activeTab === 'login' && styles.activeTab
                  ]}
                  onPress={() => setActiveTab('login')}
                >
                  <Text style={[
                    styles.tabText,
                    activeTab === 'login' && styles.activeTabText
                  ]}>
                    ログイン
                  </Text>
                </TouchableOpacity>
              </View>
              
              {error && <Text style={styles.errorText}>{error}</Text>}
              
              {activeTab === 'signup' ? (
                <View style={styles.form}>
                  <InputField
                    label="ユーザー名 (任意)"
                    placeholder="英数字のみ使用可能"
                    value={username}
                    onChangeText={setUsername}
                    autoCapitalize="none"
                  />
                  
                  <InputField
                    label="メールアドレス"
                    placeholder="example@email.com"
                    value={email}
                    onChangeText={setEmail}
                    autoCapitalize="none"
                    keyboardType="email-address"
                  />
                  
                  <DatePicker
                    label="生年月日（任意）"
                    value={birthDate}
                    onChange={setBirthDate}
                  />
                  
                  <InputField
                    label="パスワード"
                    placeholder="8文字以上"
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry
                  />
                  
                  <InputField
                    label="パスワード (確認)"
                    placeholder="パスワードを再入力"
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                    secureTextEntry
                  />
                  
                  <Button
                    title="アカウントを作成"
                    onPress={handleSignup}
                    isLoading={isLoading}
                    style={styles.button}
                  />
                </View>
              ) : (
                <View style={styles.form}>
                  <InputField
                    label="メールアドレス"
                    placeholder="example@email.com"
                    value={loginEmail}
                    onChangeText={setLoginEmail}
                    autoCapitalize="none"
                    keyboardType="email-address"
                  />
                  
                  <InputField
                    label="パスワード"
                    placeholder="パスワードを入力"
                    value={loginPassword}
                    onChangeText={setLoginPassword}
                    secureTextEntry
                  />
                  
                  <Button
                    title="ログイン"
                    onPress={handleLogin}
                    isLoading={isLoading}
                    style={styles.button}
                  />
                  
                  <Button
                    title="デモアカウントを使用"
                    variant="secondary"
                    onPress={useDemoAccount}
                    style={styles.demoButton}
                  />
                </View>
              )}
            </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  scrollContainer: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FF9494',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B6B6B',
    textAlign: 'center',
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  tabs: {
    flexDirection: 'row',
    marginBottom: 24,
    borderRadius: 12,
    backgroundColor: '#F5F5F5',
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  tabText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6B6B6B',
  },
  activeTabText: {
    color: '#FF9494',
  },
  form: {
    gap: 16,
  },
  errorText: {
    color: '#FF5252',
    textAlign: 'center',
    marginBottom: 16,
    padding: 12,
    backgroundColor: '#FFEEEE',
    borderRadius: 8,
  },
  button: {
    marginTop: 8,
  },
  demoButton: {
    marginTop: 8,
  },
});