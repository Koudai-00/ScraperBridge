import 'react-native-url-polyfill/auto';
import React, { useEffect } from 'react';
import { StyleSheet, View, ActivityIndicator } from 'react-native';
import { Redirect } from 'expo-router';
import { useStore } from '@/store';

export default function IndexPage() {
  const { user, isLoading } = useStore();

  console.log('[DEBUG] IndexPage: Component render started');
  console.log('[DEBUG] IndexPage: Current state:', {
    isLoading,
    hasUser: !!user,
    userLoggedIn: user?.isLoggedIn,
    username: user?.username,
    timestamp: new Date().toISOString(),
    renderCount: Math.random() // To track re-renders
  });

  if (isLoading) {
    console.log('[DEBUG] IndexPage: isLoading=true, showing loading screen');
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#FF9494" />
      </View>
    );
  }

  if (!user || !user.isLoggedIn) {
    console.log('[DEBUG] IndexPage: No user or not logged in, redirecting to login', {
      hasUser: !!user,
      isLoggedIn: user?.isLoggedIn
    });
    return <Redirect href="/(auth)/login" />;
  }

  console.log('[DEBUG] IndexPage: User authenticated, redirecting to tabs', {
    username: user.username
  });
  return <Redirect href="/(tabs)" />;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});