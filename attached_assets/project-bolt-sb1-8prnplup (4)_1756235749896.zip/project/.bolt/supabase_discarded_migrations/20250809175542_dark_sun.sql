/*
  # Remove duplicate video columns

  1. Changes
    - Remove `video_thumbnail_url` column from videos table (duplicate of `thumbnail_url`)
    - Remove `video_platform` column from videos table (duplicate of `source`)

  2. Notes
    - Existing application code uses `thumbnail_url` and `source` columns
    - These changes eliminate data redundancy and maintain consistency
*/

-- Remove duplicate columns
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_thumbnail_url'
  ) THEN
    ALTER TABLE videos DROP COLUMN video_thumbnail_url;
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_platform'
  ) THEN
    ALTER TABLE videos DROP COLUMN video_platform;
  END IF;
END $$;