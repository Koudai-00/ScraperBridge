/*
  # 重複する動画カラムの削除

  1. 削除するカラム
    - `video_thumbnail_url` - `thumbnail_url`と重複
    - `video_platform` - `source`と重複

  2. 理由
    - データベースの正規化
    - 既存のアプリケーションコードとの整合性
    - 保守性の向上

  3. 影響
    - 既存のアプリケーションコードは変更不要
    - `thumbnail_url`と`source`カラムを継続使用
*/

-- Remove duplicate thumbnail URL column
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_thumbnail_url'
  ) THEN
    ALTER TABLE videos DROP COLUMN video_thumbnail_url;
  END IF;
END $$;

-- Remove duplicate platform column
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'videos' AND column_name = 'video_platform'
  ) THEN
    ALTER TABLE videos DROP COLUMN video_platform;
  END IF;
END $$;